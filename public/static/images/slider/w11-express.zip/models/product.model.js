const db = require('../utils/db');

module.exports = {
  all() {
    return db.load('select * from products');
  },

  byCat(catId) {
    return db.load(`select * from products where CatID = ${catId}`);
  },

  async single(id) {
    const rows = await db.load(`select * from products where ProID = ${id}`);
    if (rows.length === 0) {
      return null;
    }

    return rows[0];
  },
};
